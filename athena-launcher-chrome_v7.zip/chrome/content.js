// ============================================================
// Athena Prompt Launcher — Content Script (Chrome + Firefox)
// ============================================================

const IS_FIREFOX = typeof browser !== 'undefined';
const EXT = IS_FIREFOX ? browser : chrome;

// ── Default Buttons ──────────────────────────────────────────
const DEFAULT_BUTTONS = [
  // Utility
  { id: 'u1', category: 'utility', label: 'New Chat', icon: '✦', action: 'newChat',    prompt: '' },
  { id: 'u2', category: 'utility', label: 'Download as Google Doc', icon: '↓', action: 'googleDoc', prompt: '' },
  // Strategy
  { id: 'd1', category: 'strategy', label: 'Scholar Summary',   icon: '🧠', prompt: 'Give me a concise summary of this scholar\'s academic profile, extracurriculars, and overall Ivy League readiness.' },
  { id: 'd2', category: 'strategy', label: 'Profile Gaps',      icon: '🧠', prompt: 'Identify the top 3 gaps in this scholar\'s profile that could hurt their chances at target schools, and suggest how to address each.' },
  { id: 'd3', category: 'strategy', label: 'University Fit',    icon: '🧠', prompt: 'Based on this scholar\'s profile, recommend the top 5 best-fit universities with a one-line reason for each.' },
  { id: 'd4', category: 'strategy', label: 'Next Steps',        icon: '🧠', prompt: 'List the 3 most important action items for this scholar in the next 30 days to strengthen their college application.' },
  // Essays
  { id: 'd5', category: 'essays', label: 'Common App Topics',   icon: '✍️', prompt: 'Suggest 3 compelling Common App essay topic ideas tailored to this scholar\'s unique experiences and personality.' },
  { id: 'd6', category: 'essays', label: 'Activity Description',icon: '✍️', prompt: 'Write a punchy 150-character activity description for this scholar\'s most impressive extracurricular. Make it specific, active, and achievement-focused.' },
  { id: 'd7', category: 'essays', label: 'Why This College',    icon: '✍️', prompt: 'Draft a 150-word "Why This College" paragraph for [University Name] based on this scholar\'s interests and goals.' },
  // Projects
  { id: 'd8', category: 'projects', label: 'Minerva Ideas',     icon: '📦', prompt: 'Suggest 3 feasible Minerva (tech capstone) project ideas based on this scholar\'s interests and skills. Include a one-line description and target competition for each.' },
  { id: 'd9', category: 'projects', label: 'Pangea Topics',     icon: '📦', prompt: 'Recommend 3 Pangea (research) topic ideas suited to this scholar\'s academic strengths. Include a research question and potential mentor domain for each.' },
  { id: 'd10', category: 'projects', label: 'Competition Fit',  icon: '📦', prompt: 'Which national or international competitions (ISEF, MIT PRIMES, etc.) is this scholar best positioned to target? Explain the fit for the top 3.' },
  // Misc
  { id: 'd11', category: 'misc', label: 'Meeting Summary',      icon: '🌐', prompt: 'Summarise the key takeaways and decisions from the last meeting with this scholar in 5 bullet points.' },
  { id: 'd12', category: 'misc', label: 'Parent Update',        icon: '🌐', prompt: 'Write a brief, professional update message for this scholar\'s parents summarising current progress and next steps.' },
];

const CAT_META = {
  utility:  { label: 'Quick Actions', color: '#1e3a5f', bg: '#dbeafe' },
  strategy: { label: 'Strategy',      color: '#1a3d2b', bg: '#d1fae5' },
  essays:   { label: 'Essays',        color: '#3b1f5e', bg: '#ede9fe' },
  projects: { label: 'Projects',      color: '#5c2d1e', bg: '#fde8d8' },
  misc:     { label: 'Misc',          color: '#374151', bg: '#f3f4f6' },
};

const STORAGE_KEY = 'athena_custom_v2';

function getCustomButtons() {
  return new Promise(resolve => {
    EXT.storage.local.get([STORAGE_KEY], r => resolve(r[STORAGE_KEY] || []));
  });
}
function saveCustomButtons(b) {
  return new Promise(resolve => EXT.storage.local.set({ [STORAGE_KEY]: b }, resolve));
}

// ── Styles ───────────────────────────────────────────────────
function injectStyles() {
  if (document.getElementById('apl-styles')) return;
  const s = document.createElement('style');
  s.id = 'apl-styles';
  s.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap');

    #apl-toggle {
      position: fixed; bottom: 24px; right: 24px; z-index: 999999;
      width: 48px; height: 48px; border-radius: 12px;
      background: #2d7d74; color: #fff; border: none; cursor: pointer;
      font-size: 20px; box-shadow: 0 2px 12px rgba(45,125,116,0.35);
      display: flex; align-items: center; justify-content: center;
      transition: transform 0.15s, box-shadow 0.15s;
    }
    #apl-toggle:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(45,125,116,0.45); }

    #apl-panel {
      position: fixed; right: 0; top: 0; bottom: 0; z-index: 999998;
      width: 320px; background: #f7f7f5;
      border-left: 1px solid #e4e4e0;
      box-shadow: -8px 0 40px rgba(0,0,0,0.10);
      display: flex; flex-direction: column;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      transform: translateX(100%); transition: transform 0.26s cubic-bezier(0.4,0,0.2,1);
    }
    #apl-panel.open { transform: translateX(0); }

    /* Header — matches Athena sidebar dark header */
    #apl-header {
      background: #1a1a2e; color: #e8e8e8;
      padding: 13px 14px; display: flex; align-items: center; justify-content: space-between;
      flex-shrink: 0; border-bottom: 1px solid #2a2a40;
    }
    #apl-header-left { display: flex; align-items: center; gap: 8px; }
    #apl-logo-dot { width: 7px; height: 7px; background: #2d7d74; border-radius: 50%; }
    #apl-header h2 { font-size: 13px; font-weight: 600; margin: 0; letter-spacing: 0.2px; }
    #apl-close {
      background: none; border: none; color: #9ca3af; cursor: pointer;
      font-size: 16px; padding: 3px 6px; border-radius: 5px; transition: color 0.15s, background 0.15s;
    }
    #apl-close:hover { color: #fff; background: #333350; }

    /* Tabs — pill style like Athena's Chat/Student File/Meetings */
    #apl-tabs {
      display: flex; gap: 6px; padding: 10px 12px;
      background: #fff; border-bottom: 1px solid #e4e4e0; flex-shrink: 0;
    }
    .apl-tab {
      flex: 1; padding: 7px 4px; border-radius: 20px; border: 1px solid #e4e4e0;
      background: transparent; cursor: pointer; font-size: 11.5px; font-weight: 500;
      color: #6b7280; font-family: inherit; transition: all 0.15s;
    }
    .apl-tab.active { background: #2d7d74; color: #fff; border-color: #2d7d74; }

    #apl-body { flex: 1; overflow-y: auto; padding: 12px; }
    #apl-body::-webkit-scrollbar { width: 4px; }
    #apl-body::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 4px; }

    /* Fallback output */
    #apl-output {
      background: #fff; border: 1.5px solid #a7d4d0; border-radius: 10px;
      padding: 11px; margin-bottom: 12px; display: none;
    }
    #apl-output.visible { display: block; }
    #apl-output-label { font-size: 10px; font-weight: 700; color: #2d7d74; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 5px; }
    #apl-output-text {
      font-family: 'SFMono-Regular', monospace; font-size: 11px; line-height: 1.55;
      background: #f0faf9; border-radius: 6px; padding: 9px;
      color: #1a1a1a; white-space: pre-wrap; word-break: break-word; max-height: 110px; overflow-y: auto;
    }
    #apl-output-actions { display: flex; gap: 6px; margin-top: 8px; }
    .apl-btn-copy {
      flex: 1; background: #2d7d74; color: white; border: none; border-radius: 7px;
      padding: 6px 0; font-size: 12px; font-weight: 600; cursor: pointer; font-family: inherit; transition: opacity 0.15s;
    }
    .apl-btn-copy:hover { opacity: 0.88; }
    .apl-btn-dismiss {
      background: none; border: 1px solid #e4e4e0; border-radius: 7px;
      padding: 6px 10px; font-size: 12px; color: #6b7280; cursor: pointer; font-family: inherit;
    }

    /* Category sections */
    .apl-cat-section { margin-bottom: 14px; }
    .apl-cat-header { margin-bottom: 6px; }
    .apl-cat-badge {
      display: inline-block; font-size: 10px; font-weight: 700; padding: 2px 9px;
      border-radius: 20px; text-transform: uppercase; letter-spacing: 0.3px;
    }
    .apl-prompts { display: flex; flex-direction: column; gap: 4px; }

    /* Regular prompt buttons */
    .apl-prompt-btn {
      background: #fff; border: 1px solid #e4e4e0; border-radius: 9px;
      padding: 9px 12px; font-size: 12.5px; color: #1a1a1a; cursor: pointer;
      font-family: inherit; text-align: left; transition: all 0.12s;
      display: flex; align-items: center; gap: 8px; line-height: 1.3;
    }
    .apl-prompt-btn:hover { border-color: #2d7d74; background: #f0faf9; color: #2d7d74; }
    .apl-prompt-btn .apl-icon { font-size: 13px; flex-shrink: 0; width: 16px; text-align: center; }

    /* Utility buttons — styled like Athena's active pill */
    .apl-utility-btn {
      background: #2d7d74; border: none; border-radius: 9px;
      padding: 10px 12px; font-size: 12.5px; color: #fff; cursor: pointer;
      font-family: inherit; text-align: left; transition: all 0.12s;
      display: flex; align-items: center; gap: 8px; line-height: 1.3; font-weight: 500;
    }
    .apl-utility-btn:hover { background: #236860; }
    .apl-utility-btn .apl-icon { font-size: 14px; flex-shrink: 0; }

    /* Manage form */
    .apl-form-group { margin-bottom: 9px; }
    .apl-label { font-size: 10.5px; font-weight: 700; color: #6b7280; text-transform: uppercase; letter-spacing: 0.4px; display: block; margin-bottom: 3px; }
    .apl-input, .apl-select, .apl-textarea {
      width: 100%; border: 1px solid #e4e4e0; border-radius: 7px;
      padding: 7px 10px; font-size: 12.5px; font-family: inherit;
      background: #fff; color: #1a1a1a; outline: none; transition: border-color 0.15s;
    }
    .apl-input:focus, .apl-select:focus, .apl-textarea:focus { border-color: #2d7d74; }
    .apl-textarea { resize: vertical; min-height: 65px; }
    .apl-btn-add {
      background: #2d7d74; color: white; border: none; border-radius: 7px;
      padding: 9px 0; width: 100%; font-size: 12.5px; font-weight: 600;
      cursor: pointer; font-family: inherit; margin-top: 2px; transition: opacity 0.15s;
    }
    .apl-btn-add:hover { opacity: 0.88; }
    hr.apl-divider { border: none; border-top: 1px solid #e4e4e0; margin: 12px 0; }
    .apl-manage-item {
      background: #fff; border: 1px solid #e4e4e0; border-radius: 8px;
      padding: 9px 11px; margin-bottom: 5px; display: flex; gap: 8px;
    }
    .apl-manage-info { flex: 1; min-width: 0; }
    .apl-manage-label { font-size: 12px; font-weight: 600; margin-bottom: 2px; }
    .apl-manage-prompt { font-size: 10.5px; color: #6b7280; line-height: 1.4; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .apl-btn-del {
      background: none; border: none; color: #d1d5db; cursor: pointer;
      font-size: 13px; padding: 2px 4px; border-radius: 4px; transition: color 0.15s; flex-shrink: 0;
    }
    .apl-btn-del:hover { color: #ef4444; }
    .apl-empty { text-align: center; padding: 18px; color: #9ca3af; font-size: 12px; }

    /* Toast */
    #apl-toast {
      position: fixed; bottom: 82px; right: 20px; z-index: 9999999;
      background: #1a1a2e; color: #e8e8e8; padding: 8px 14px;
      border-radius: 8px; font-size: 12px; font-family: 'Inter', sans-serif;
      pointer-events: none; opacity: 0; transition: opacity 0.2s;
      border-left: 3px solid #2d7d74;
    }
    #apl-toast.show { opacity: 1; }
  `;
  document.head.appendChild(s);
}

// ── DOM Builder ───────────────────────────────────────────────
function buildPanel() {
  if (document.getElementById('apl-panel')) return;
  const toggle = document.createElement('button');
  toggle.id = 'apl-toggle';
  toggle.title = 'Athena Prompt Launcher';
  toggle.innerHTML = '⚡';

  const panel = document.createElement('div');
  panel.id = 'apl-panel';
  panel.innerHTML = `
    <div id="apl-header">
      <div id="apl-header-left">
        <div id="apl-logo-dot"></div>
        <h2>Prompt Launcher</h2>
      </div>
      <button id="apl-close">✕</button>
    </div>
    <div id="apl-tabs">
      <button class="apl-tab active" data-tab="dashboard">Dashboard</button>
      <button class="apl-tab" data-tab="manage">+ Manage</button>
    </div>
    <div id="apl-body">
      <div id="apl-page-dashboard">
        <div id="apl-output">
          <div id="apl-output-label">Prompt copied — paste into chat</div>
          <div id="apl-output-text"></div>
          <div id="apl-output-actions">
            <button class="apl-btn-copy" id="apl-copy-btn">Copy again</button>
            <button class="apl-btn-dismiss" id="apl-dismiss-btn">✕</button>
          </div>
        </div>
        <div id="apl-categories"></div>
      </div>
      <div id="apl-page-manage" style="display:none">
        <div class="apl-form-group">
          <label class="apl-label">Button Label</label>
          <input class="apl-input" id="apl-new-label" placeholder="e.g. Summarise Profile" />
        </div>
        <div class="apl-form-group">
          <label class="apl-label">Category</label>
          <select class="apl-select" id="apl-new-cat">
            <option value="strategy">Strategy</option>
            <option value="essays">Essays</option>
            <option value="projects">Projects</option>
            <option value="misc">Misc</option>
          </select>
        </div>
        <div class="apl-form-group">
          <label class="apl-label">Prompt Text</label>
          <textarea class="apl-textarea" id="apl-new-prompt" placeholder="Write the exact prompt…"></textarea>
        </div>
        <button class="apl-btn-add" id="apl-add-btn">+ Add Button</button>
        <hr class="apl-divider">
        <div id="apl-manage-list"></div>
      </div>
    </div>
  `;

  const toast = document.createElement('div');
  toast.id = 'apl-toast';
  document.body.appendChild(toggle);
  document.body.appendChild(panel);
  document.body.appendChild(toast);
}

// ── Utility: Toast ────────────────────────────────────────────
function showToast(msg, duration = 2200) {
  const t = document.getElementById('apl-toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

// ── Special Actions ───────────────────────────────────────────

// NEW CHAT: find and click any "new chat" trigger in the Athena UI
function actionNewChat() {
  const selectors = [
    // Common "new chat / compose / plus" patterns
    'button[aria-label*="new chat" i]',
    'button[aria-label*="new conversation" i]',
    'button[title*="new chat" i]',
    'button[class*="new-chat"]',
    'button[class*="newChat"]',
    'a[href*="new"]',
    // Look for "+" button in the sidebar header area
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) { el.click(); showToast('✦ New chat started'); return; }
  }
  // Fallback: look for any button with "+" or "new" text near the sidebar
  const buttons = Array.from(document.querySelectorAll('button, a'));
  const match = buttons.find(b => {
    const t = (b.textContent || '').trim().toLowerCase();
    return t === '+' || t === 'new chat' || t === 'new' || t === 'compose';
  });
  if (match) { match.click(); showToast('✦ New chat started'); return; }

  // Last resort: reload to home
  showToast('⚠ Could not find new chat button');
}

// GOOGLE DOC: extract last AI response → copy to clipboard → open Google Docs
function actionGoogleDoc() {
  // Try to find the last assistant message text in the page
  const msgSelectors = [
    '[class*="assistant"] [class*="content"]',
    '[class*="ai-message"]',
    '[class*="bot-message"]',
    '[data-role="assistant"]',
    '[class*="response"]',
    '[class*="message"]:last-child',
  ];

  let text = '';
  for (const sel of msgSelectors) {
    const els = document.querySelectorAll(sel);
    if (els.length) {
      text = els[els.length - 1].innerText.trim();
      if (text.length > 30) break;
    }
  }

  // Wider fallback: grab the last large text block that looks like an AI reply
  if (!text || text.length < 30) {
    const divs = Array.from(document.querySelectorAll('div, p'))
      .filter(el => el.innerText && el.innerText.trim().length > 200)
      .filter(el => !el.querySelector('input, textarea, button'));
    if (divs.length) text = divs[divs.length - 1].innerText.trim();
  }

  if (!text || text.length < 30) {
    showToast('⚠ Could not find AI response text');
    return;
  }

  // Copy to clipboard
  navigator.clipboard.writeText(text).then(() => {
    // Open a new blank Google Doc
    window.open('https://docs.google.com/document/create', '_blank');
    showToast('📋 Response copied — paste into the new Doc (Ctrl+V)', 4000);
  }).catch(() => {
    showToast('⚠ Clipboard access denied');
  });
}

// ── Chat Input Helpers ────────────────────────────────────────
function findSendButton() {
  const btns = [
    'button[type="submit"]',
    'button[aria-label*="send" i]',
    'button[title*="send" i]',
  ];
  for (const s of btns) {
    const b = document.querySelector(s);
    if (b) return b;
  }
  const textareas = document.querySelectorAll('textarea');
  for (const ta of textareas) {
    const parent = ta.closest('form') || ta.parentElement?.parentElement;
    if (parent) {
      const buttons = parent.querySelectorAll('button');
      if (buttons.length) return buttons[buttons.length - 1];
    }
  }
  return null;
}

function sendPrompt(prompt) {
  const inputSelectors = [
    'textarea[placeholder*="Type your request"]',
    'textarea[placeholder*="request"]',
    'textarea[placeholder*="message"]',
    'div[contenteditable="true"]',
    'input[type="text"][placeholder*="request"]',
  ];
  for (const sel of inputSelectors) {
    const el = document.querySelector(sel);
    if (el) {
      el.focus();
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, prompt); else el.value = prompt;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      setTimeout(() => {
        const btn = findSendButton();
        if (btn && !btn.disabled) btn.click();
        else el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      }, 120);
      return true;
    }
  }
  return false;
}

// ── Dispatcher ────────────────────────────────────────────────
function handleButton(btn) {
  // Close panel → show chat
  document.getElementById('apl-panel').classList.remove('open');
  document.getElementById('apl-toggle').style.display = 'flex';

  if (btn.action === 'newChat')   { actionNewChat();   return; }
  if (btn.action === 'googleDoc') { actionGoogleDoc(); return; }

  const ok = sendPrompt(btn.prompt);
  if (ok) {
    showToast('✓ Prompt sent!');
  } else {
    navigator.clipboard.writeText(btn.prompt).catch(() => {});
    document.getElementById('apl-output-text').textContent = btn.prompt;
    document.getElementById('apl-output').classList.add('visible');
    document.getElementById('apl-panel').classList.add('open');
    document.getElementById('apl-toggle').style.display = 'none';
    showToast('⚠ Chat box not found — prompt copied');
  }
}

// ── Render Dashboard ──────────────────────────────────────────
async function renderDashboard(custom) {
  const all = [...DEFAULT_BUTTONS, ...custom];
  const catOrder = ['utility', 'strategy', 'essays', 'projects', 'misc'];
  const container = document.getElementById('apl-categories');
  container.innerHTML = '';
  for (const cat of catOrder) {
    const btns = all.filter(b => b.category === cat);
    if (!btns.length) continue;
    const meta = CAT_META[cat];
    const sec = document.createElement('div');
    sec.className = 'apl-cat-section';
    sec.innerHTML = `
      <div class="apl-cat-header">
        <span class="apl-cat-badge" style="background:${meta.bg};color:${meta.color}">${meta.label}</span>
      </div>
      <div class="apl-prompts" id="apl-cat-${cat}"></div>`;
    container.appendChild(sec);
    const grid = sec.querySelector(`#apl-cat-${cat}`);
    btns.forEach(b => {
      const el = document.createElement('button');
      el.className = b.action ? 'apl-utility-btn' : 'apl-prompt-btn';
      el.innerHTML = `<span class="apl-icon">${b.icon}</span>${b.label}`;
      el.addEventListener('click', () => handleButton(b));
      grid.appendChild(el);
    });
  }
}

// ── Render Manage ─────────────────────────────────────────────
async function renderManage(custom) {
  const list = document.getElementById('apl-manage-list');
  if (!custom.length) { list.innerHTML = '<div class="apl-empty">No custom buttons yet.</div>'; return; }
  list.innerHTML = custom.map((b, i) => `
    <div class="apl-manage-item">
      <div class="apl-manage-info">
        <div class="apl-manage-label">${b.icon || ''} ${b.label}</div>
        <div class="apl-manage-prompt">${b.prompt}</div>
      </div>
      <button class="apl-btn-del" data-i="${i}">✕</button>
    </div>`).join('');
  list.querySelectorAll('.apl-btn-del').forEach(d => {
    d.addEventListener('click', async () => {
      const c = await getCustomButtons();
      c.splice(+d.dataset.i, 1);
      await saveCustomButtons(c);
      renderManage(c); renderDashboard(c);
    });
  });
}

// ── Init ──────────────────────────────────────────────────────
async function init() {
  injectStyles();
  buildPanel();
  const custom = await getCustomButtons();
  renderDashboard(custom);
  renderManage(custom);

  const toggle = document.getElementById('apl-toggle');
  const panel  = document.getElementById('apl-panel');

  toggle.addEventListener('click', () => {
    panel.classList.toggle('open');
    toggle.style.display = panel.classList.contains('open') ? 'none' : 'flex';
  });
  document.getElementById('apl-close').addEventListener('click', () => {
    panel.classList.remove('open'); toggle.style.display = 'flex';
  });
  document.querySelectorAll('.apl-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.apl-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('apl-page-dashboard').style.display = tab.dataset.tab === 'dashboard' ? 'block' : 'none';
      document.getElementById('apl-page-manage').style.display    = tab.dataset.tab === 'manage'    ? 'block' : 'none';
    });
  });
  document.getElementById('apl-copy-btn').addEventListener('click', () => {
    navigator.clipboard.writeText(document.getElementById('apl-output-text').textContent)
      .then(() => showToast('✓ Copied!'));
  });
  document.getElementById('apl-dismiss-btn').addEventListener('click', () => {
    document.getElementById('apl-output').classList.remove('visible');
  });
  document.getElementById('apl-add-btn').addEventListener('click', async () => {
    const label  = document.getElementById('apl-new-label').value.trim();
    const cat    = document.getElementById('apl-new-cat').value;
    const prompt = document.getElementById('apl-new-prompt').value.trim();
    if (!label || !prompt) { alert('Fill in label and prompt.'); return; }
    const c = await getCustomButtons();
    const icons = { strategy:'🧠', essays:'✍️', projects:'📦', misc:'🌐' };
    c.push({ id: 'c'+Date.now(), category: cat, label, icon: icons[cat] || '●', prompt });
    await saveCustomButtons(c);
    document.getElementById('apl-new-label').value = '';
    document.getElementById('apl-new-prompt').value = '';
    renderManage(c); renderDashboard(c);
    showToast('✓ Button added!');
  });
}

init();
