// ============================================================
// Athena Prompt Launcher v4 — Chrome Extension
// ============================================================

const EXT         = chrome;
const STORAGE_KEY = 'athena_custom_v4';
const DARK_KEY    = 'athena_dark_v4';
const COLLAPSE_KEY= 'athena_collapse_v4';

const DEFAULT_BUTTONS = [
  { id:'u1', category:'utility',  label:'New Chat',             icon:'✦', action:'newChat', prompt:'' },
  { id:'d1', category:'strategy', label:'Scholar Summary',      icon:'🧠', prompt:'Give me a concise summary of this scholar\'s academic profile, extracurriculars, and overall Ivy League readiness.' },
  { id:'d2', category:'strategy', label:'Profile Gaps',         icon:'🧠', prompt:'Identify the top 3 gaps in this scholar\'s profile that could hurt their chances at target schools, and suggest how to address each.' },
  { id:'d3', category:'strategy', label:'University Fit',       icon:'🧠', prompt:'Based on this scholar\'s profile, recommend the top 5 best-fit universities with a one-line reason for each.' },
  { id:'d4', category:'strategy', label:'Next Steps',           icon:'🧠', prompt:'List the 3 most important action items for this scholar in the next 30 days to strengthen their college application.' },
  { id:'d5', category:'essays',   label:'Common App Topics',    icon:'✍️', prompt:'Suggest 3 compelling Common App essay topic ideas tailored to this scholar\'s unique experiences and personality.' },
  { id:'d6', category:'essays',   label:'Activity Description', icon:'✍️', prompt:'Write a punchy 150-character activity description for this scholar\'s most impressive extracurricular. Make it specific, active, and achievement-focused.' },
  { id:'d7', category:'essays',   label:'Why This College',     icon:'✍️', prompt:'Draft a 150-word "Why This College" paragraph for [University Name] based on this scholar\'s interests and goals.' },
  { id:'d8', category:'projects', label:'Minerva Ideas',        icon:'📦', prompt:'Suggest 3 feasible Minerva (tech capstone) project ideas based on this scholar\'s interests and skills. Include a one-line description and target competition for each.' },
  { id:'d9', category:'projects', label:'Pangea Topics',        icon:'📦', prompt:'Recommend 3 Pangea (research) topic ideas suited to this scholar\'s academic strengths. Include a research question and potential mentor domain for each.' },
  { id:'d10',category:'projects', label:'Competition Fit',      icon:'📦', prompt:'Which national or international competitions (ISEF, MIT PRIMES, etc.) is this scholar best positioned to target? Explain the fit for the top 3.' },
  { id:'d11',category:'misc',     label:'Meeting Summary',      icon:'🌐', prompt:'Summarise the key takeaways and decisions from the last meeting with this scholar in 5 bullet points.' },
  { id:'d12',category:'misc',     label:'Parent Update',        icon:'🌐', prompt:'Write a brief, professional update message for this scholar\'s parents summarising current progress and next steps.' },
];

const CAT_META = {
  utility:  { label:'Quick Actions', color:'#1e3a5f', bg:'#dbeafe' },
  strategy: { label:'Strategy',      color:'#1a3d2b', bg:'#d1fae5' },
  essays:   { label:'Essays',        color:'#3b1f5e', bg:'#ede9fe' },
  projects: { label:'Projects',      color:'#5c2d1e', bg:'#fde8d8' },
  misc:     { label:'Misc',          color:'#374151', bg:'#f3f4f6' },
};
const CAT_ICONS = { strategy:'🧠', essays:'✍️', projects:'📦', misc:'🌐' };

const getCustomButtons  = () => new Promise(r => EXT.storage.local.get([STORAGE_KEY],  d => r(d[STORAGE_KEY]  || [])));
const saveCustomButtons = b  => new Promise(r => EXT.storage.local.set({ [STORAGE_KEY]: b }, r));
const getCollapsed      = () => new Promise(r => EXT.storage.local.get([COLLAPSE_KEY], d => r(d[COLLAPSE_KEY] || {})));
const saveCollapsed     = c  => new Promise(r => EXT.storage.local.set({ [COLLAPSE_KEY]: c }, r));
const getDark = () => new Promise(r => EXT.storage.local.get([DARK_KEY], d => r(d[DARK_KEY] || false)));
const saveDark = v => new Promise(r => EXT.storage.local.set({ [DARK_KEY]: v }, r));

// ── Styles ────────────────────────────────────────────────────
function injectStyles() {
  if (document.getElementById('apl-styles')) return;
  const el = document.createElement('style');
  el.id = 'apl-styles';
  el.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');

    #apl-toggle {
      position:fixed; bottom:24px; right:24px; z-index:999999;
      width:48px; height:48px; border-radius:14px;
      background:#2d7d74; color:#fff; border:none; cursor:pointer;
      font-size:20px; box-shadow:0 4px 16px rgba(45,125,116,.4);
      display:flex; align-items:center; justify-content:center;
      transition:transform .15s, box-shadow .15s;
    }
    #apl-toggle:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(45,125,116,.5); }

    #apl-panel {
      position:fixed; right:16px; top:16px; bottom:16px; z-index:999998;
      width:320px; background:#f7f7f5;
      border-radius:20px;
      border:1px solid #e0e0db;
      box-shadow:0 16px 56px rgba(0,0,0,.18), 0 2px 8px rgba(0,0,0,.07);
      display:flex; flex-direction:column; overflow:hidden;
      font-family:'Inter',-apple-system,sans-serif;
      transform:translateX(calc(100% + 36px));
      transition:transform .28s cubic-bezier(.4,0,.2,1);
    }
    #apl-panel.open { transform:translateX(0); }

    #apl-header {
      background:#1a1a2e; color:#e8e8e8;
      padding:13px 14px; display:flex; align-items:center; justify-content:space-between; flex-shrink:0;
    }
    #apl-header-left { display:flex; align-items:center; gap:8px; }
    #apl-logo-dot { width:7px; height:7px; background:#2d7d74; border-radius:50%; }
    #apl-header h2 { font-size:13px; font-weight:600; margin:0; }
    #apl-close {
      background:none; border:none; color:#9ca3af; cursor:pointer;
      font-size:16px; padding:3px 6px; border-radius:5px; transition:color .15s, background .15s;
    }
    #apl-close:hover { color:#fff; background:#2a2a45; }

    #apl-tabs {
      display:flex; gap:5px; padding:9px 10px;
      background:#fff; border-bottom:1px solid #e4e4e0; flex-shrink:0;
    }
    .apl-tab {
      flex:1; padding:6px 2px; border-radius:20px; border:1px solid #e4e4e0;
      background:transparent; cursor:pointer; font-size:11px; font-weight:500;
      color:#6b7280; font-family:inherit; transition:all .15s;
    }
    .apl-tab.active { background:#2d7d74; color:#fff; border-color:#2d7d74; }

    #apl-body { flex:1; overflow-y:auto; padding:12px; }
    #apl-body::-webkit-scrollbar { width:3px; }
    #apl-body::-webkit-scrollbar-thumb { background:#d1d5db; border-radius:3px; }

    /* Fallback output */
    #apl-output {
      background:#fff; border:1.5px solid #a7d4d0; border-radius:11px;
      padding:11px; margin-bottom:12px; display:none;
    }
    #apl-output.visible { display:block; }
    #apl-output-label { font-size:10px; font-weight:700; color:#2d7d74; text-transform:uppercase; letter-spacing:.5px; margin-bottom:5px; }
    #apl-output-text {
      font-family:monospace; font-size:11px; line-height:1.55;
      background:#f0faf9; border-radius:6px; padding:9px;
      color:#1a1a1a; white-space:pre-wrap; word-break:break-word; max-height:100px; overflow-y:auto;
    }
    #apl-output-actions { display:flex; gap:6px; margin-top:8px; }
    .apl-btn-copy {
      flex:1; background:#2d7d74; color:white; border:none; border-radius:7px;
      padding:6px 0; font-size:12px; font-weight:600; cursor:pointer; font-family:inherit;
    }
    .apl-btn-dismiss {
      background:none; border:1px solid #e4e4e0; border-radius:7px;
      padding:6px 10px; font-size:12px; color:#6b7280; cursor:pointer; font-family:inherit;
    }

    /* ── Category sections — collapsible ── */
    .apl-cat-section { margin-bottom:8px; }

    .apl-cat-header {
      display:flex; align-items:center; justify-content:space-between;
      padding:7px 10px; border-radius:10px; cursor:pointer;
      user-select:none; transition:background .12s;
      background:#fff; border:1px solid #e4e4e0;
    }
    .apl-cat-header:hover { background:#f0faf9; border-color:#2d7d74; }

    .apl-cat-header-left { display:flex; align-items:center; gap:7px; }
    .apl-cat-badge {
      font-size:10px; font-weight:700; padding:2px 9px;
      border-radius:20px; text-transform:uppercase; letter-spacing:.3px;
    }
    .apl-cat-count { font-size:10px; color:#9ca3af; }

    .apl-chevron {
      font-size:10px; color:#9ca3af; transition:transform .2s;
      display:inline-block; line-height:1;
    }
    .apl-chevron.open { transform:rotate(180deg); }

    .apl-prompts {
      display:flex; flex-direction:column; gap:4px;
      padding:6px 0 2px;
      overflow:hidden;
      max-height:600px;
      transition:max-height .22s ease, padding .22s ease, opacity .18s ease;
      opacity:1;
    }
    .apl-prompts.collapsed {
      max-height:0; padding:0; opacity:0; pointer-events:none;
    }

    .apl-prompt-btn {
      background:#fff; border:1px solid #e4e4e0; border-radius:10px;
      padding:9px 10px; font-size:12px; color:#1a1a1a; cursor:pointer;
      font-family:inherit; text-align:left; transition:all .12s;
      display:flex; align-items:center; gap:7px; width:100%;
    }
    .apl-prompt-btn:hover { border-color:#2d7d74; background:#f0faf9; color:#2d7d74; }
    .apl-prompt-btn .apl-icon { font-size:13px; flex-shrink:0; width:16px; text-align:center; }
    .apl-prompt-btn .apl-btn-label { flex:1; text-align:left; }

    .apl-utility-btn {
      background:#2d7d74; border:none; border-radius:10px;
      padding:10px 12px; font-size:12px; color:#fff; cursor:pointer;
      font-family:inherit; text-align:left; transition:background .12s;
      display:flex; align-items:center; gap:7px; font-weight:500; width:100%;
    }
    .apl-utility-btn:hover { background:#236860; }

    .apl-btn-actions { display:flex; gap:2px; flex-shrink:0; opacity:0; transition:opacity .12s; }
    .apl-prompt-btn:hover .apl-btn-actions { opacity:1; }
    .apl-action-icon {
      background:none; border:none; cursor:pointer; font-size:12px;
      padding:2px 4px; border-radius:4px; color:#9ca3af; transition:all .12s; line-height:1;
    }
    .apl-action-icon:hover { background:#e4e4e0; }
    .apl-action-icon.edit:hover { color:#2d7d74; }
    .apl-action-icon.del:hover  { color:#ef4444; }

    /* ── Edit modal ── */
    .apl-overlay {
      position:fixed; inset:0; z-index:9999999;
      background:rgba(0,0,0,.45); backdrop-filter:blur(3px);
      display:none; align-items:center; justify-content:center;
    }
    .apl-overlay.open { display:flex; }
    .apl-modal-box {
      background:#fff; border-radius:18px; padding:20px;
      width:296px; box-shadow:0 20px 60px rgba(0,0,0,.22);
      font-family:'Inter',sans-serif;
    }
    .apl-modal-box h3 { font-size:14px; font-weight:600; margin:0 0 14px; color:#1a1a1a; }
    .apl-modal-actions { display:flex; gap:8px; margin-top:14px; }
    .apl-modal-save {
      flex:1; background:#2d7d74; color:white; border:none; border-radius:9px;
      padding:9px; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit;
    }
    .apl-modal-cancel {
      background:none; border:1px solid #e4e4e0; border-radius:9px;
      padding:9px 14px; font-size:13px; color:#6b7280; cursor:pointer; font-family:inherit;
    }

    /* Manage / form */
    .apl-form-group { margin-bottom:9px; }
    .apl-label { font-size:10.5px; font-weight:700; color:#6b7280; text-transform:uppercase; letter-spacing:.4px; display:block; margin-bottom:3px; }
    .apl-input,.apl-select,.apl-textarea {
      width:100%; border:1px solid #e4e4e0; border-radius:8px;
      padding:7px 10px; font-size:12.5px; font-family:inherit;
      background:#fff; color:#1a1a1a; outline:none; transition:border-color .15s; box-sizing:border-box;
    }
    .apl-input:focus,.apl-select:focus,.apl-textarea:focus { border-color:#2d7d74; }
    .apl-textarea { resize:vertical; min-height:60px; }
    .apl-btn-add {
      background:#2d7d74; color:white; border:none; border-radius:8px;
      padding:9px 0; width:100%; font-size:12.5px; font-weight:600;
      cursor:pointer; font-family:inherit; transition:opacity .15s;
    }
    .apl-btn-add:hover { opacity:.88; }
    hr.apl-divider { border:none; border-top:1px solid #e4e4e0; margin:12px 0; }

    .apl-manage-item {
      background:#fff; border:1px solid #e4e4e0; border-radius:10px;
      padding:9px 11px; margin-bottom:5px;
    }
    .apl-manage-top { display:flex; align-items:flex-start; gap:8px; }
    .apl-manage-info { flex:1; min-width:0; }
    .apl-manage-label { font-size:12px; font-weight:600; margin-bottom:2px; }
    .apl-manage-prompt { font-size:10.5px; color:#6b7280; line-height:1.4; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .apl-manage-btns { display:flex; gap:4px; flex-shrink:0; }
    .apl-manage-btn {
      background:none; border:1px solid #e4e4e0; border-radius:6px; cursor:pointer;
      font-size:12px; padding:3px 7px; color:#6b7280; transition:all .12s; font-family:inherit;
    }
    .apl-manage-btn.edit:hover { border-color:#2d7d74; color:#2d7d74; background:#f0faf9; }
    .apl-manage-btn.del:hover  { border-color:#ef4444; color:#ef4444; background:#fef2f2; }

    .apl-empty { text-align:center; padding:18px; color:#9ca3af; font-size:12px; }

    #apl-toast {
      position:fixed; bottom:82px; right:20px; z-index:99999999;
      background:#1a1a2e; color:#e8e8e8; padding:8px 14px;
      border-radius:10px; font-size:12px; font-family:'Inter',sans-serif;
      pointer-events:none; opacity:0; transition:opacity .2s;
      border-left:3px solid #2d7d74; white-space:nowrap;
    }
    #apl-toast.show { opacity:1; }
    /* ── Dark Mode Toggle ── */
    #apl-dark-toggle {
      background:none; border:1px solid #3a3a55; border-radius:20px;
      cursor:pointer; font-size:13px; padding:3px 8px;
      color:#9ca3af; transition:all .2s; display:flex; align-items:center; gap:4px;
    }
    #apl-dark-toggle:hover { background:#2a2a45; color:#fff; }
    #apl-header-right { display:flex; align-items:center; gap:6px; }

    /* ── Dark Mode Overrides ── */
    #apl-panel.dark { background:#18181b; border-color:#2d2d35; }
    #apl-panel.dark #apl-tabs { background:#1f1f27; border-bottom-color:#2d2d35; }
    #apl-panel.dark .apl-tab { border-color:#2d2d35; color:#9ca3af; }
    #apl-panel.dark .apl-tab.active { background:#2d7d74; color:#fff; border-color:#2d7d74; }
    #apl-panel.dark #apl-output { background:#1f1f27; border-color:#2d7d74; }
    #apl-panel.dark #apl-output-text { background:#141418; color:#e2e8f0; }
    #apl-panel.dark .apl-cat-header { background:#1f1f27; border-color:#2d2d35; color:#e2e8f0; }
    #apl-panel.dark .apl-cat-header:hover { background:#252530; border-color:#2d7d74; }
    #apl-panel.dark .apl-cat-count { color:#6b7280; }
    #apl-panel.dark .apl-chevron { color:#6b7280; }
    #apl-panel.dark .apl-prompt-btn { background:#1f1f27; border-color:#2d2d35; color:#e2e8f0; }
    #apl-panel.dark .apl-prompt-btn:hover { border-color:#2d7d74; background:#1a2e2c; color:#4ecca3; }
    #apl-panel.dark .apl-manage-item { background:#1f1f27; border-color:#2d2d35; }
    #apl-panel.dark .apl-manage-label { color:#e2e8f0; }
    #apl-panel.dark .apl-manage-prompt { color:#6b7280; }
    #apl-panel.dark .apl-manage-btn { border-color:#2d2d35; color:#6b7280; }
    #apl-panel.dark .apl-manage-btn.edit:hover { border-color:#2d7d74; color:#4ecca3; background:#1a2e2c; }
    #apl-panel.dark .apl-manage-btn.del:hover  { border-color:#ef4444; color:#ef4444; background:#2d1a1a; }
    #apl-panel.dark .apl-input,
    #apl-panel.dark .apl-select,
    #apl-panel.dark .apl-textarea { background:#141418; border-color:#2d2d35; color:#e2e8f0; }
    #apl-panel.dark .apl-input:focus,
    #apl-panel.dark .apl-select:focus,
    #apl-panel.dark .apl-textarea:focus { border-color:#2d7d74; }
    #apl-panel.dark .apl-label { color:#6b7280; }
    #apl-panel.dark hr.apl-divider { border-top-color:#2d2d35; }
    #apl-panel.dark .apl-empty { color:#4b5563; }
    #apl-panel.dark .apl-action-icon:hover { background:#2d2d35; }
    #apl-panel.dark .apl-btn-dismiss { border-color:#2d2d35; color:#6b7280; }
    #apl-modal-overlay.dark .apl-modal-box { background:#1f1f27; border:1px solid #2d2d35; }
    #apl-modal-overlay.dark .apl-modal-box h3 { color:#e2e8f0; }
    #apl-modal-overlay.dark .apl-input,
    #apl-modal-overlay.dark .apl-select,
    #apl-modal-overlay.dark .apl-textarea { background:#141418; border-color:#2d2d35; color:#e2e8f0; }
    #apl-modal-overlay.dark .apl-label { color:#6b7280; }
    #apl-modal-overlay.dark .apl-modal-cancel { border-color:#2d2d35; color:#6b7280; }

  `;
  document.head.appendChild(el);
}

// ── DOM ───────────────────────────────────────────────────────
function buildPanel() {
  if (document.getElementById('apl-panel')) return;
  document.body.insertAdjacentHTML('beforeend', `
    <button id="apl-toggle" title="Athena Prompt Launcher">⚡</button>

    <div id="apl-panel">
      <div id="apl-header">
        <div id="apl-header-left"><div id="apl-logo-dot"></div><h2>Prompt Launcher</h2></div>
        <div id="apl-header-right"><button id="apl-dark-toggle" title="Toggle dark mode">🌙</button><button id="apl-close">✕</button></div>
      </div>
      <div id="apl-tabs">
        <button class="apl-tab active" data-tab="dashboard">Dashboard</button>
        <button class="apl-tab"        data-tab="manage">+ Manage</button>
      </div>
      <div id="apl-body">

        <div id="apl-page-dashboard">
          <div id="apl-output">
            <div id="apl-output-label">Prompt copied — paste into chat</div>
            <div id="apl-output-text"></div>
            <div id="apl-output-actions">
              <button class="apl-btn-copy"    id="apl-copy-btn">Copy again</button>
              <button class="apl-btn-dismiss" id="apl-dismiss-btn">✕</button>
            </div>
          </div>
          <div id="apl-categories"></div>
        </div>

        <div id="apl-page-manage" style="display:none">
          <div class="apl-form-group">
            <label class="apl-label">Button Label</label>
            <input class="apl-input" id="apl-new-label" placeholder="e.g. Summarise Profile" />
          </div>
          <div class="apl-form-group">
            <label class="apl-label">Category</label>
            <select class="apl-select" id="apl-new-cat">
              <option value="strategy">Strategy</option>
              <option value="essays">Essays</option>
              <option value="projects">Projects</option>
              <option value="misc">Misc</option>
            </select>
          </div>
          <div class="apl-form-group">
            <label class="apl-label">Prompt Text</label>
            <textarea class="apl-textarea" id="apl-new-prompt" placeholder="Write the exact prompt…"></textarea>
          </div>
          <button class="apl-btn-add" id="apl-add-btn">+ Add Button</button>
          <hr class="apl-divider">
          <div id="apl-manage-list"></div>
        </div>

      </div>
    </div>

    <!-- Edit modal -->
    <div class="apl-overlay" id="apl-modal-overlay">
      <div class="apl-modal-box">
        <h3>✏ Edit Button</h3>
        <input type="hidden" id="apl-edit-id" />
        <div class="apl-form-group">
          <label class="apl-label">Label</label>
          <input class="apl-input" id="apl-edit-label" />
        </div>
        <div class="apl-form-group">
          <label class="apl-label">Category</label>
          <select class="apl-select" id="apl-edit-cat">
            <option value="strategy">Strategy</option>
            <option value="essays">Essays</option>
            <option value="projects">Projects</option>
            <option value="misc">Misc</option>
          </select>
        </div>
        <div class="apl-form-group">
          <label class="apl-label">Prompt</label>
          <textarea class="apl-textarea" id="apl-edit-prompt" style="min-height:80px"></textarea>
        </div>
        <div class="apl-modal-actions">
          <button class="apl-modal-save"   id="apl-modal-save">Save Changes</button>
          <button class="apl-modal-cancel" id="apl-modal-cancel">Cancel</button>
        </div>
      </div>
    </div>

    <div id="apl-toast"></div>
  `);
}

// ── Toast ─────────────────────────────────────────────────────
let _tt;
function showToast(msg, ms=2400) {
  const t = document.getElementById('apl-toast');
  clearTimeout(_tt); t.textContent = msg; t.classList.add('show');
  _tt = setTimeout(() => t.classList.remove('show'), ms);
}

// ── New Chat ──────────────────────────────────────────────────
function actionNewChat() {
  for (const s of ['button[aria-label*="new chat" i]','button[title*="new chat" i]']) {
    const el = document.querySelector(s); if (el) { el.click(); showToast('✦ New chat started'); return; }
  }
  const m = Array.from(document.querySelectorAll('button,a'))
    .find(b => ['new chat','new','+'].includes(b.textContent.trim().toLowerCase()));
  m ? (m.click(), showToast('✦ New chat started')) : showToast('⚠ Could not find new chat button');
}

// ── Send prompt ───────────────────────────────────────────────
function findSendBtn() {
  for (const s of ['button[type="submit"]','button[aria-label*="send" i]','button[title*="send" i]']) {
    const b = document.querySelector(s); if (b) return b;
  }
  for (const ta of document.querySelectorAll('textarea')) {
    const p = ta.closest('form') || ta.parentElement?.parentElement;
    if (p) { const bs = p.querySelectorAll('button'); if (bs.length) return bs[bs.length-1]; }
  }
}

function sendPrompt(prompt) {
  for (const sel of ['textarea[placeholder*="Type your request"]','textarea[placeholder*="request"]','textarea[placeholder*="message"]','div[contenteditable="true"]']) {
    const el = document.querySelector(sel);
    if (!el) continue;
    el.focus();
    const proto  = el.tagName==='TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
    if (setter) setter.call(el, prompt); else el.value = prompt;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    setTimeout(() => {
      const b = findSendBtn();
      if (b && !b.disabled) b.click();
      else el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',keyCode:13,bubbles:true}));
    }, 120);
    return true;
  }
  return false;
}

function handleButton(b) {
  document.getElementById('apl-panel').classList.remove('open');
  document.getElementById('apl-toggle').style.display = 'flex';
  if (b.action === 'newChat') { actionNewChat(); return; }
  const ok = sendPrompt(b.prompt);
  if (ok) { showToast('✓ Prompt sent!'); }
  else {
    navigator.clipboard.writeText(b.prompt).catch(()=>{});
    document.getElementById('apl-output-text').textContent = b.prompt;
    document.getElementById('apl-output').classList.add('visible');
    document.getElementById('apl-panel').classList.add('open');
    document.getElementById('apl-toggle').style.display = 'none';
    showToast('⚠ Chat box not found — prompt copied');
  }
}

// ── Render Dashboard ──────────────────────────────────────────
async function renderDashboard(custom) {
  const all       = [...DEFAULT_BUTTONS, ...custom];
  const collapsed = await getCollapsed();
  const container = document.getElementById('apl-categories');
  container.innerHTML = '';

  for (const cat of ['utility','strategy','essays','projects','misc']) {
    const btns = all.filter(b => b.category === cat);
    if (!btns.length) continue;
    const meta    = CAT_META[cat];
    const isOpen  = !collapsed[cat];          // default = open
    const count   = btns.length;

    const sec = document.createElement('div');
    sec.className = 'apl-cat-section';

    // Header (clickable)
    const header = document.createElement('div');
    header.className = 'apl-cat-header';
    header.innerHTML = `
      <div class="apl-cat-header-left">
        <span class="apl-cat-badge" style="background:${meta.bg};color:${meta.color}">${meta.label}</span>
        <span class="apl-cat-count">${count}</span>
      </div>
      <span class="apl-chevron ${isOpen ? 'open' : ''}">▼</span>`;

    // Grid (collapsible)
    const grid = document.createElement('div');
    grid.className = 'apl-prompts' + (isOpen ? '' : ' collapsed');

    btns.forEach(b => {
      const el = document.createElement('button');
      if (b.action) {
        el.className = 'apl-utility-btn';
        el.innerHTML = `<span class="apl-icon">${b.icon}</span><span>${b.label}</span>`;
        el.addEventListener('click', () => handleButton(b));
      } else {
        const isCustom = b.id.startsWith('c');
        el.className = 'apl-prompt-btn';
        el.innerHTML = `
          <span class="apl-icon">${b.icon}</span>
          <span class="apl-btn-label">${b.label}</span>
          <span class="apl-btn-actions">
            ${isCustom ? `<button class="apl-action-icon edit" title="Edit">✏</button><button class="apl-action-icon del" title="Delete">✕</button>` : ''}
          </span>`;
        el.addEventListener('click', e => { if (!e.target.closest('.apl-btn-actions')) handleButton(b); });
        if (isCustom) {
          el.querySelector('.edit').addEventListener('click', e => { e.stopPropagation(); openEditModal(b.id); });
          el.querySelector('.del').addEventListener('click',  e => {
            e.stopPropagation();
            if (!confirm(`Delete "${b.label}"?`)) return;
            getCustomButtons().then(c => saveCustomButtons(c.filter(x => x.id!==b.id))).then(init);
          });
        }
      }
      grid.appendChild(el);
    });

    // Toggle collapse on header click
    header.addEventListener('click', async () => {
      const c = await getCollapsed();
      const nowCollapsed = !grid.classList.contains('collapsed');
      if (nowCollapsed) { c[cat] = true; grid.classList.add('collapsed'); header.querySelector('.apl-chevron').classList.remove('open'); }
      else              { delete c[cat]; grid.classList.remove('collapsed'); header.querySelector('.apl-chevron').classList.add('open'); }
      await saveCollapsed(c);
    });

    sec.appendChild(header);
    sec.appendChild(grid);
    container.appendChild(sec);
  }
}

// ── Render Manage ─────────────────────────────────────────────
async function renderManage(custom) {
  const list = document.getElementById('apl-manage-list');
  if (!custom.length) { list.innerHTML = '<div class="apl-empty">No custom buttons yet.</div>'; return; }
  list.innerHTML = '';
  custom.forEach(b => {
    const item = document.createElement('div'); item.className = 'apl-manage-item';
    item.innerHTML = `
      <div class="apl-manage-top">
        <div class="apl-manage-info">
          <div class="apl-manage-label">${b.icon||''} ${b.label}</div>
          <div class="apl-manage-prompt">${b.prompt}</div>
        </div>
        <div class="apl-manage-btns">
          <button class="apl-manage-btn edit">✏</button>
          <button class="apl-manage-btn del">✕</button>
        </div>
      </div>`;
    item.querySelector('.edit').addEventListener('click', () => openEditModal(b.id));
    item.querySelector('.del').addEventListener('click', () => {
      if (!confirm(`Delete "${b.label}"?`)) return;
      getCustomButtons().then(c => saveCustomButtons(c.filter(x => x.id!==b.id))).then(init);
    });
    list.appendChild(item);
  });
}

// ── Edit Modal ────────────────────────────────────────────────
async function openEditModal(id) {
  const btn = (await getCustomButtons()).find(b => b.id === id);
  if (!btn) return;
  document.getElementById('apl-edit-id').value     = id;
  document.getElementById('apl-edit-label').value  = btn.label;
  document.getElementById('apl-edit-cat').value    = btn.category;
  document.getElementById('apl-edit-prompt').value = btn.prompt;
  document.getElementById('apl-modal-overlay').classList.add('open');
}

// ── Init ──────────────────────────────────────────────────────
async function init() {
  injectStyles();
  buildPanel();
  const custom = await getCustomButtons();
  renderDashboard(custom);
  renderManage(custom);

  const toggle = document.getElementById('apl-toggle');
  const panel  = document.getElementById('apl-panel');
  if (toggle._b) return; toggle._b = true;

  // ── Dark mode init ──
  const applyDark = (dark) => {
    panel.classList.toggle('dark', dark);
    document.getElementById('apl-modal-overlay').classList.toggle('dark', dark);
    const btn = document.getElementById('apl-dark-toggle');
    if (btn) btn.textContent = dark ? '☀️' : '🌙';
  };
  getDark().then(applyDark);
  document.getElementById('apl-dark-toggle').addEventListener('click', async () => {
    const current = await getDark();
    await saveDark(!current);
    applyDark(!current);
  });

  toggle.addEventListener('click', () => {
    panel.classList.toggle('open');
    toggle.style.display = panel.classList.contains('open') ? 'none' : 'flex';
  });
  document.getElementById('apl-close').addEventListener('click', () => {
    panel.classList.remove('open'); toggle.style.display = 'flex';
  });

  document.querySelectorAll('.apl-tab').forEach(tab => tab.addEventListener('click', () => {
    document.querySelectorAll('.apl-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('apl-page-dashboard').style.display = tab.dataset.tab==='dashboard' ? 'block' : 'none';
    document.getElementById('apl-page-manage').style.display    = tab.dataset.tab==='manage'    ? 'block' : 'none';
  }));

  document.getElementById('apl-copy-btn').addEventListener('click', () =>
    navigator.clipboard.writeText(document.getElementById('apl-output-text').textContent).then(() => showToast('✓ Copied!')));
  document.getElementById('apl-dismiss-btn').addEventListener('click', () =>
    document.getElementById('apl-output').classList.remove('visible'));

  document.getElementById('apl-add-btn').addEventListener('click', async () => {
    const label = document.getElementById('apl-new-label').value.trim();
    const cat   = document.getElementById('apl-new-cat').value;
    const prompt= document.getElementById('apl-new-prompt').value.trim();
    if (!label||!prompt) { alert('Fill in label and prompt.'); return; }
    const c = await getCustomButtons();
    c.push({ id:'c'+Date.now(), category:cat, label, icon:CAT_ICONS[cat]||'●', prompt });
    await saveCustomButtons(c);
    document.getElementById('apl-new-label').value  = '';
    document.getElementById('apl-new-prompt').value = '';
    showToast('✓ Button added!'); init();
  });

  document.getElementById('apl-modal-save').addEventListener('click', async () => {
    const id    = document.getElementById('apl-edit-id').value;
    const label = document.getElementById('apl-edit-label').value.trim();
    const cat   = document.getElementById('apl-edit-cat').value;
    const prompt= document.getElementById('apl-edit-prompt').value.trim();
    if (!label||!prompt) { alert('Fill in all fields.'); return; }
    const c = await getCustomButtons();
    const i = c.findIndex(b => b.id===id);
    if (i>-1) c[i] = {...c[i], label, category:cat, icon:CAT_ICONS[cat]||'●', prompt};
    await saveCustomButtons(c);
    document.getElementById('apl-modal-overlay').classList.remove('open');
    showToast('✓ Button updated!'); init();
  });
  document.getElementById('apl-modal-cancel').addEventListener('click', () =>
    document.getElementById('apl-modal-overlay').classList.remove('open'));
}

init();
